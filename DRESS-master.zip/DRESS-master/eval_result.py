from sklearn.metrics import cohen_kappa_score
from sklearn.metrics import f1_score
from sklearn.metrics import accuracy_score
import config
import os
import pprint
import warnings
import numpy as np
import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')


def show_bar_chart(title, all_res, dress_res_dbscan, dress_res_optics):
    n_groups = len(all_res)
    # create plot
    fig, ax = plt.subplots()
    index = np.arange(n_groups)
    bar_width = 0.275
    opacity = 0.8
    if dress_res_dbscan:
        rects1 = plt.bar(index, dress_res_dbscan, bar_width,
                         alpha=opacity,
                         color='b',
                         label='DRESS DBSCAN')

    if dress_res_optics:
        rects3 = plt.bar(index+bar_width, dress_res_optics, bar_width,
                         alpha=opacity,
                         color='g',
                         label='DRESS OPTICS')

    rects2 = plt.bar(index + 2*bar_width, all_res, bar_width,
                     alpha=opacity,
                     color='r',
                     label='All Features')

    plt.xlabel('iterations')
    plt.ylabel('Scores')
    plt.title(title)
    plt.xticks(index + bar_width, range(1, len(all_res)+2))
    plt.legend()


    plt.tight_layout()
    plt.show()


def eval_result(read_from):
    acc_scores = []
    kappa_scores = []
    f1_scores = []
    for i in range(1, 11):
        y_pred, y_true = np.loadtxt(read_from + '/res' + str(i) + '.csv', delimiter=",", dtype=str)
        kappa_scores.append(cohen_kappa_score(y_true, y_pred, labels=None, weights=None, sample_weight=None))
        f1_scores.append(f1_score(y_true, y_pred, labels=None, pos_label=1, average='macro', sample_weight=None))
        acc_scores.append(accuracy_score(y_true, y_pred, normalize=True, sample_weight=None))
    create_dic = lambda x, y: {"mean": x, "standard_deviation": y}
    eval_dic = {
        "path": read_from,
        "acc": create_dic(np.mean(acc_scores), np.std(acc_scores, ddof=1)),
        "f1": create_dic(np.mean(f1_scores), np.std(f1_scores, ddof=1)),
        "kappa": create_dic(np.mean(kappa_scores), np.std(kappa_scores, ddof=1)),
    }
    pprint.pprint(eval_dic)
    return acc_scores

if __name__ == "__main__":
    result = config.Result_dir
    print("Evaluate Result")
    dress_res_optics = False
    dress_res_dbscan = False
    all_res = False
    if os.path.exists(result + "/naive_bayes/All/res1.csv"):
        all_res = eval_result(result + "/naive_bayes/All")
        print("----------------------------------------------")
    if os.path.exists(result + "/naive_bayes/DRESS/dbscan/res1.csv"):
        dress_res_dbscan = eval_result(result + "/naive_bayes/DRESS/dbscan")
        print("----------------------------------------------")
    if os.path.exists(result + "/naive_bayes/DRESS/optics/res1.csv"):
        dress_res_optics = eval_result(result + "/naive_bayes/DRESS/optics")
        print("----------------------------------------------")
    if all_res:
        show_bar_chart("Accuracy Score with Naive Bayes", all_res=all_res, dress_res_dbscan=dress_res_dbscan,
                       dress_res_optics=dress_res_optics)
    dress_res_optics = False
    dress_res_dbscan = False
    all_res = False
    if os.path.exists(result + "/knn/All/res1.csv"):
        all_res = eval_result(result + "/knn/All")
        print("----------------------------------------------")
    if os.path.exists(result + "/knn/DRESS/dbscan/res1.csv"):
        dress_res_dbscan = eval_result(result + "/knn/DRESS/dbscan")
        print("----------------------------------------------")
    if os.path.exists(result + "/knn/DRESS/optics/res1.csv"):
        print("----------------------------------------------")
        dress_res_optics = eval_result(result + "/knn/DRESS/optics")
        print("----------------------------------------------")
    if all_res:
        show_bar_chart("Accuracy Score with KNN", all_res=all_res, dress_res_dbscan=dress_res_dbscan,
                       dress_res_optics=dress_res_optics)
