#sourc for HEOM : https://github.com/andybaoxv/COPDGene/blob/master/utils/heom.py
import numpy as np
def heom(data, features_type, val_max_col, val_min_col, m, n):
    """This function computes Heterogeneous Euclidean Overlap Metric distance
    between m-th sample and n-th sample in a given dataset
    Parameters
    ----------
    data: array, shape(n_instances,n_features)
        array containing the original dataset

    features_type: list, len(n_features)
        list containing types of all the features, the values should fall into
        the set ['binary','categorical','interval','continuous']

    val_max_col: list of floats
        max value for each column
    val_min_col: list of floats
        min value for each column

    m: int
        row number of the first sample in the dataset
    n: int
        row number of the second sample in the dataset
    Returns
    -------
    dist_heom: float
        HEOM distance between i-th sample and k-th sample in dataset specified
        by data
        Ausgabe ist ein 2D Array,dessen Einträge sind,
         die Distanz zwiscjen dem Objekt in der i-ten Zeile und das Objekt ind der j-ten Spalten
    """
    n_instances, n_features = data.shape
    dist_temp = list(range(n_features))
    dist_sum = 0
    for j in range(n_features):
        if (isinstance(data[m, j], float) and isinstance(data[n, j], float)) and (np.isnan(data[m, j]) or np.isnan(data[n, j])):
            dist_temp[j] = 1.
        elif features_type[j] in ['binary', 'categorical', 'ordinal']:
            if data[m, j] == data[n, j]:
                dist_temp[j] = 0.
            else:
                dist_temp[j] = 1.
        elif features_type[j] in ['interval', 'continuous']:
            # Normalisierung und Distanzbrerechnung
            if val_max_col[j] == val_min_col[j]:
                dist_temp[j] = 0
            else:
                dist_temp[j] = (float(data[m, j]) - float(data[n, j])) / (val_max_col[j] - val_min_col[j])
        else:
            pass
        dist_sum += dist_temp[j] ** 2
    dist_heom = dist_sum ** 0.5

    return dist_heom


def test_heom():
    import numpy as np
    data = np.array([[10., 1.],
                     [5., 0.],
                     [3., 1.],
                     [1., 0.]])
    features_type = ['interval', 'binary']
    val_max_col = [10, 0]
    val_min_col = [1, 0]
    print(data)
    print(
    heom(data, features_type, val_max_col, val_min_col, 0, 1))
    print(
    heom(data, features_type, val_max_col, val_min_col, 0, 2))
    print(
    heom(data, features_type, val_max_col, val_min_col, 0, 3))


def heom_array(data, features_type):
    """Compute heom distance between pairwise samples in data
    Parameters
    ----------
    data: array,shape(n_instances,n_features)
        array containing the dataset
    features_type: list, len(n_features)
        types of every feature
    Returns
    -------
    mtr_heom: array, shape(n_instances,n_instances)
        array containing pairwise heom distance
    """
    import numpy as np
    n_instances, n_features = data.shape
    mtr_heom = np.zeros((n_instances, n_instances))

    val_max_col = [0] * n_features
    val_min_col = [0] * n_features
    for j in range(n_features):
        if features_type[j] in ['interval', 'continuous']:
            for i in range(n_instances):
                if not np.isnan(data[i, j]):
                    val_max_col[j] = float(data[i, j])
                    val_min_col[j] = float(data[i, j])
                    break
            for i in range(n_instances):
                if not np.isnan(data[i, j]):
                    if float(data[i, j]) > val_max_col[j]:
                        val_max_col[j] = float(data[i, j])
                    if float(data[i, j]) < val_min_col[j]:
                        val_min_col[j] = float(data[i, j])

    for i in range(n_instances - 1):
        for j in range(i + 1, n_instances):
            mtr_heom[i, j] = heom(data, features_type, val_max_col, val_min_col, i, j)
            mtr_heom[j, i] = mtr_heom[i, j]
    return mtr_heom


def heom_array_ids(data1, data2, features_type):
    """Compute heom distance between pairwise samples in data
    Parameters
    ----------
    data: array,shape(n_instances,n_features)
        array containing the dataset
    features_type: list, len(n_features)
        types of every feature
    Returns
    -------
    mtr_heom: array, shape(n_instances,n_instances)
        array containing pairwise heom distance
    """
    import numpy as np
    n1_instances, n_features = data1.shape
    n2_instances = data2.shape[0]
    mtr_heom = np.zeros((n1_instances, n2_instances))

    val_max_col = [0] * n_features
    val_min_col = [0] * n_features
    for j in range(n_features):
        if features_type[j] in ['interval', 'continuous']:
            for i in range(n1_instances):
                if not np.isnan(data1[i, j]):
                    val_max_col[j] = float(data1[i, j])
                    val_min_col[j] = float(data1[i, j])
                    break
            for i in range(n1_instances):
                if not np.isnan(data1[i, j]):
                    if float(data1[i, j]) > val_max_col[j]:
                        val_max_col[j] = float(data1[i, j])
                    if float(data1[i, j]) < val_min_col[j]:
                        val_min_col[j] = float(data1[i, j])

            for i in range(n2_instances):
                if not np.isnan(data2[i, j]):
                    if float(data2[i, j]) > val_max_col[j]:
                        val_max_col[j] = float(data2[i, j])
                    if float(data2[i, j]) < val_min_col[j]:
                        val_min_col[j] = float(data2[i, j])

    for i in range(n1_instances):
        for j in range(n2_instances):
            d = list()
            d.append(data1[i])
            d.append(data2[j])
            d = np.array(d)
            mtr_heom[i, j] = heom(d, features_type, val_max_col, val_min_col, 0, 1)
    return mtr_heom


def test_heom_array():
    data = np.array([[10, 1],
                     [5., 0.],
                     [3., 1.],
                     [1., 0.]])
    #print(data)
    features_type = ['interval', 'binary']


    return heom_array(data, features_type)




#print(calc_eps(arr, 3))


