from pathlib import Path
DATA_PATH = Path(r"C:\Users\Jojo\Desktop\SHIP_Daten\SHIPdatStudents.csv")
FEATURE_PATH = Path(r"C:\Users\Jojo\Desktop\SHIP_Daten\features.csv")
FEMALE = None  # None all data , False use Male, True use Female
target_class = "Class"
Constraints_amount = 12
Result_dir = "Result"  # should be in the project path


