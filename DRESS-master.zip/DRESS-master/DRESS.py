import clustering
import data_model
import config


class DRESS:
    def __init__(self, data_path=False, data=False, features_path=False, contranits_path=False,constraints=False, clustering_method="DBSCAN",feamle=None, limt=None,seed=25852):
        if not data:
            self.data = data_model.DataModel(data_path, feature_path=features_path, female=feamle, limit=limt)
        else:
            self.data = data
        if not constraints:
            self.constraints = data_model.Constraints(contranits_path, self.data.data_frame, config.Constraints_amount, seed)
        else:
            self.constraints = constraints
        self.clustering_method = clustering_method
        self.cand_subspaces = False

    # input_subspace_list ist eine Liste an alle potentiellen subspaces, die bereits gemerged sind
    # subspace braucht q_dist attribut
    # subspace braucht eine nl_avg und eine ml_avg Funktion
    # subspace braucht s_best und s_prev attribute

    def filter(self, cand_subspace_list, s_best):
        filterd_cand_sub = list()
        for sub_new in cand_subspace_list:
            sdist = sub_new[0]
            if s_best.get_dist_qualtiy() >= sub_new[0].get_dist_qualtiy():
                sdist = s_best
            if (sub_new[1].nl_avg_dist - sdist.nl_avg_dist) - (sub_new[1].ml_avg_dist - sdist.ml_avg_dist) > 0:
                filterd_cand_sub.append(sub_new)
        return filterd_cand_sub

    def get_best_subspace(self, subspaces):
        top_qual = subspaces[0].get_qualtiy()
        best_sub = subspaces[0]
        for sub in subspaces:
            if sub.get_qualtiy() > top_qual:
                top_qual = sub.get_qualtiy()
                best_sub = sub
        return best_sub

    def create_init_subspaces(self):
        subspaces = list()
        for f in self.data.features:
            subspace = data_model.Subspace([f], self.data, self.constraints)
            subspaces.append(subspace)
            self.set_subspace(subspace)
        return subspaces

    def start(self):
            self.cand_subspaces = self.create_init_subspaces()
            s_best = self.get_best_subspace(self.cand_subspaces)
            print("length: " + str(len(self.cand_subspaces)))
            if s_best:
                self.cand_subspaces.remove(s_best)
            while True:
                print(s_best.get_qualtiy())
                pot_cand_subspaces = list()
                for sub in self.cand_subspaces:
                    merged_sub = s_best.merge(sub)
                    merged_sub.clac_dist_quality(self.data, self.constraints)
                    pot_cand_subspaces.append((sub, merged_sub))
                pot_cand_subspaces = self.filter(pot_cand_subspaces, s_best)
                for pot_sub in pot_cand_subspaces:
                    self.set_subspace(pot_sub[1])
                if not pot_cand_subspaces:
                    return s_best
                sbest_new = pot_cand_subspaces[0]
                qbest_new = sbest_new[1].get_qualtiy()
                for pot_sub in pot_cand_subspaces:
                    if pot_sub[1].get_qualtiy() > qbest_new:
                        sbest_new = pot_sub
                        qbest_new = pot_sub[1].get_qualtiy()
                print("cand q:" + str(qbest_new))
                if qbest_new < s_best.get_qualtiy():
                    return s_best
                self.cand_subspaces.remove(sbest_new[0])
                if len(self.cand_subspaces) == 0:
                    return s_best
                s_best = sbest_new[1]
                print("new lengt " + str(len(self.cand_subspaces)))



    #Ergibniss: Dictionary mit id von objekten und label aus dem Clustriing
    def set_subspace(self, subspace, show_cluster=False):
        print("Clustering with Subspace:" + str(subspace))
        features = subspace.get_features()
        feature_names = [f.name for f in features]
        features_types = [f.kind for f in features]
        data = self.data.get_by_features(feature_names)
        subspace.dist_dic = self.data.get_dist_matrix(data, features_types)
        if self.clustering_method == "DBSCAN":
            subspace.cluster_res = clustering.with_dbscan(subspace, show_cluster)
        else:
            subspace.cluster_res = clustering.with_optics(subspace, show_cluster)
        subspace.clac_cons_quality(self.constraints)
        print("q " + str(subspace.get_qualtiy()))
        return subspace



#Beispil fuer Clustering von Dress mit Subsbace und Features
data_path = config.DATA_PATH
feature_path = config.FEATURE_PATH
constraints_path = False


def get_feature_from_name(names):
    res = list()
    for f in dr.data.features:
        if f.name in names:
            res.append(f)
    return res
if __name__ == "__main__":

    # create Dress Object
    print(" Use DRESS with: ")
    print("(1) DBSCAN ")
    print("(2) OPTICS ")
    alg = input("Select method for Evaluation: ")
    while int(alg) not in [1, 2]:
        alg = input("Select method for Evaluation: ")
    alg = "DBSCAN" if int(alg) == 1 else "OPTICS"
    dr = DRESS(data_path, features_path=feature_path, constraints=False, clustering_method=alg, feamle=config.FEMALE, limt=False, seed=357)
    #sbest = dr.start()
    #print("best sub: " + str(sbest))
    sub = data_model.Subspace(get_feature_from_name(('gx_rs738408_s2', 'atc_c07a_s2', 'gx_rs2143571_s2', 'gx_rs2281135_s2', 'hyperlipid_s2', 'gx_rs738409_s2')))
    dr.set_subspace(sub, True)
