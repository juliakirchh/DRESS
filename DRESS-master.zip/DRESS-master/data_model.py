import pandas
import dplython
import numpy as np
import heom
import config

class Feature:
    def __init__(self, name, kind):
        self.name = name
        self.kind = kind

    def __str__(self):
        return self.name

    def __repr__(self):
        return str(self)

    def __eq__(self, other):
        return self.name == other.name

    def __hash__(self):
        return hash(self.name)



class Subspace:
    def __init__(self, features, data=False, cons=False):
        self.features = frozenset(features)
        self.cons_quality = False
        self.nl_avg_dist = None
        self.ml_avg_dist = None
        self.cluster_res = False
        self.dist_dic = False
        if data and cons:
            self.clac_dist_quality(data, cons)

    def get_features(self):
        res = [x for x in self.features]
        return res

    #Return new Subspace
    def merge(self, sub2):
        feature_list = self.get_features()
        feature_list.extend(sub2.get_features())
        new_sub = Subspace(list(feature_list))
        return new_sub

    #compute the quality of subspace with respect to the constraints
    def clac_cons_quality(self, cons):
        if self.cluster_res:
            ml_len = len(cons.ml)
            nl_len = len(cons.nl)
            ml_sat = 0
            nl_sat = 0
            for id1, id2 in cons.nl:
                if self.cluster_res[id1] == -1 or self.cluster_res[id2] == -1 or (self.cluster_res[id1] != self.cluster_res[id2]):
                    nl_sat += 1
            for id1, id2 in cons.ml:
                if not(self.cluster_res[id1] == -1 or self.cluster_res[id2] == -1) and (self.cluster_res[id1] == self.cluster_res[id2]):
                    ml_sat += 1
            self.cons_quality = (nl_sat + ml_sat)/(ml_len + nl_len)
            #just for tset
            return {
                "ml_sat": ml_sat,
                "nl_sat": nl_sat,
                "result": self.cons_quality
            }
    # compute dist quality with respect to the constraints
    def clac_dist_quality(self,data, cons):
        feature_names = [f.name for f in self.features]
        features_types = [f.kind for f in self.features]
        data = data.get_by_features(feature_names)
        ids = cons.get_all_ids()
        filter_dic = lambda x, y: dict([(i, x[i]) for i in x if i in y])
        data = filter_dic(data, ids)
        dist_dic = DataModel.get_dist_matrix(data, features_types)
        nl_avg_dist = 0
        ml_avg_dist = 0
        len_nl = len(cons.nl)
        len_ml = len(cons.ml)
        keys = list(dist_dic)
        for id1, id2 in cons.nl:
            nl_avg_dist += dist_dic[id1][keys.index(id2)]
        for id1, id2 in cons.ml:
            ml_avg_dist += dist_dic[id1][keys.index(id2)]
        nl_avg_dist /= len_nl
        ml_avg_dist /= len_ml
        self.nl_avg_dist = nl_avg_dist
        self.ml_avg_dist = ml_avg_dist

    def get_dist_qualtiy(self):
        if self.ml_avg_dist >= 0 and self.nl_avg_dist >= 0:
            return self.nl_avg_dist - self.ml_avg_dist
        else:
            return False

    def get_qualtiy(self):
        if self.ml_avg_dist >= 0 and self.nl_avg_dist >= 0 and self.cons_quality >= 0:
            return self.get_dist_qualtiy() * self.cons_quality
        else:
            return False

    def __str__(self):
        return str(set(self.features))

    def __repr__(self):
        return str(self)


class DataModel:
    def __init__(self, data_path, feature_path=False, female=None, limit=None, ignore_feature=["id", config.target_class]):
        try:
            df = dplython.DplyFrame(pandas.read_csv(data_path))
            if 'id' not in df.columns:
                df = self.create_data_with_ids(df)
            self.data_frame = df
            self.data_frame.set_index("id", drop=False)
            if female == True:
                self.data_frame = df >> dplython.sift(dplython.X.female_s0_s0 == 1)
            elif female == False:
                self.data_frame = df >> dplython.sift(dplython.X.female_s0_s0 == 0)
        except(ImportError):
            print("The Data path cannot be found")
            raise ImportError
        if limit:
            self.data_frame = self.data_frame >> dplython.head(limit)
        if feature_path:
            self.features = list()
            try:
                print("Read feature Types")
                features_type = dplython.DplyFrame(pandas.read_csv(feature_path))
                for col in self.data_frame:
                    if col not in ignore_feature:
                        self.features.append(Feature(col, features_type[col]._values[0]))
            except:
                raise Exception("The is an Error in the Feature Types file, please make sure that all types are defined")

    def get_by_features(self, features):
        data = self.data_frame
        ids = data["id"]
        np_data = data[features].to_numpy()
        res = dict(zip(ids, np_data))
        return res

    @classmethod
    def get_dist_matrix(cls, data, types):
        clustering_data = np.array(list(data.values()))
        ids = list(data.keys())
        dist_matrix = heom.heom_array(clustering_data, types)
        res = dict(zip(ids, dist_matrix))
        return res

    @classmethod
    def create_data_with_ids(cls, df, create_file=True):
        df['id'] = range(0, len(df))
        cols = df.columns.tolist()
        cols = cols[-1:] + cols[:-1]
        df = df[cols]
        if create_file:
            df.to_csv('data_with_id.csv', index=False)
        return df




class Constraints:
    def __init__(self, cons_path=None, data_frame=None, amount=None, seed=None):
        if cons_path:
            try:
                nl_constraints = dplython.DplyFrame(pandas.read_csv(cons_path["NL"]))
                ml_constraints = dplython.DplyFrame(pandas.read_csv(cons_path["ML"]))
            except:
                print("The constraints file can not be found, The Constraints will be generated ")
        elif data_frame is not None and amount and seed:
            print("Genarate Constraints")
            from constraint_generator import generate_constraints
            nl_constraints = generate_constraints(dataframe=data_frame, constraint_type="NL", class_name=config.target_class, amount=amount, seed=seed)
            ml_constraints = generate_constraints(dataframe=data_frame, constraint_type="ML", class_name=config.target_class ,amount=amount, seed=seed+1)
        self.nl = list(zip(nl_constraints.id_1,  nl_constraints.id_2))
        self.ml = list(zip(ml_constraints.id_1, ml_constraints.id_2))

    def get_all_ids(self):
        ids = set()
        for id1, id2 in self.ml:
            ids.add(id1)
            ids.add(id2)

        for id1, id2 in self.nl:
            ids.add(id1)
            ids.add(id2)
        return ids

    def __str__(self):
        return str({
            "NL": self.nl,
            "ML": self.ml,
        })

    def __repr__(self):
        return str(self)


if __name__ == "__main__":
    #test cons quality
    class Cons:
        def __init__(self, ml, nl):
            self.ml = ml
            self.nl = nl

    cons = Cons(((1, 2), (5, 3), (2, 3), (2, 9)),
                ((1, 4), (2, 5), (3, 5), (7, 9))
                )

    cluster_res = {
        1: 0,
        2: 0,
        3: -1,
        4: 1,
        5: -1,
        6: 1,
        7: 2,
        8: 0,
        9: 2,
    }
    subspace = Subspace()
    subspace.cluster_res = cluster_res
    print(subspace.clac_cons_quality(cons))

    # test constaints class
    data_path = config.DATA_PATH
    feature_path = config.FEATURE_PATH


    df = dplython.DplyFrame(pandas.read_csv(data_path))

    const = Constraints(cons_path=False, data_frame=df, amount=2, seed=5)
    print(const.nl)
    print(const.ml)
    print(const)

    f1 = Feature("som_gew_s2", "interval")
    f2 = Feature("alkligt_s2", "interval")
    subspace.add_feature(f1)
    subspace.add_feature(f2)
    data = DataModel(data_path, feature_path=feature_path)
    subspace.clac_dist_quality(data, const)














