from matplotlib import gridspec
from sklearn.cluster import DBSCAN
from sklearn.cluster import OPTICS
import heom
import numpy as np
import matplotlib.pyplot as plt

def show_clustr_plot_opt(db, X):
    labels = db.labels_[db.ordering_]
    colors = ['g.', 'r.', 'b.', 'y.', 'c.']
    n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
    for klass, color in zip(range(0, 5), colors):
        Xk = X[db.labels_ == klass]
        plt.plot(Xk[:, 0], Xk[:, 1], color, alpha=0.3)
    plt.plot(X[db.labels_ == -1, 0], X[db.labels_ == -1, 1], 'k+', alpha=0.1)
    plt.title('Estimated number of clusters: with Optics %d' % n_clusters_)
    plt.show()


def show_cluster_plot(db, X):
    core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
    core_samples_mask[db.core_sample_indices_] = True
    labels = db.labels_
    unique_labels = set(labels)

    n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
    n_noise_ = list(labels).count(-1)

    print('Estimated number of clusters with DBSCAN: %d' % n_clusters_)
    print('Estimated number of noise points with DBSCAN: %d' % n_noise_)

    colors = [plt.cm.Spectral(each)
              for each in np.linspace(0, 1, len(unique_labels))]
    for k, col in zip(unique_labels, colors):
        if k == -1:
            # Black used for noise.
            col = [0, 0, 0, 1]
        class_member_mask = (labels == k)

        xy = X[class_member_mask & core_samples_mask]
        plt.plot(xy[:, 0], xy[:, 1], 'o', markerfacecolor=tuple(col),
                 markeredgecolor='k', markersize=14)

        xy = X[class_member_mask & ~core_samples_mask]
        plt.plot(xy[:, 0], xy[:, 1], 'o', markerfacecolor=tuple(col),
                 markeredgecolor='k', markersize=6)

    plt.title('Estimated number of clusters: with DBSCAN %d' % n_clusters_)
    plt.show()




def get_k_te_smallest_dis(dist_arr, k):
    idx = np.argpartition(dist_arr, k)
    return dist_arr[idx[k]]


def calc_eps(dist_arr, min_pts):
    dm = list()
    for i in range(0, len(dist_arr)):
        dm.append((get_k_te_smallest_dis(dist_arr[i], min_pts)))
    dm.sort()
    p1 = (0, dm[0])
    p2 = (len(dm)-1, dm[-1])
    p1 = np.asarray(p1)
    p2 = np.asarray(p2)
    norm_1_2 = np.linalg.norm(p2-p1)
    maxi = 0
    plt.plot([p1[0], p2[0]],[p1[1],p2[1]])
    j = 0
    for i in range(1, len(dm)):
        plt.plot(i, dm[i], 'ro')
        d = abs(np.cross(p2 - p1, np.asarray((i, dm[i])) - p1) / norm_1_2)
        if d > maxi:
            maxi = d
            j = i

    plt.plot(j,dm[j], "g^")
    plt.show()
    return dm[j]


def with_dbscan(subspace, show_cluster=False):
    dist_dic = subspace.dist_dic
    dist_matrix = np.array(list(dist_dic.values()))
    ids = list(dist_dic.keys())
    min_pts = int(round(np.log(len(ids))))
    eps = calc_eps(dist_matrix, min_pts)
    eps = eps if eps > 0 else 0.5
    cluster = DBSCAN(eps=eps, min_samples=min_pts, metric='precomputed').fit(dist_matrix)
    if show_cluster:
        show_cluster_plot(cluster, dist_matrix)
    id_cluster = dict((b, a) for (a, b) in zip(cluster.labels_, ids))
    return id_cluster

######## Clustering with OPTICS algorithm
######## no pre-computation of epcs neccessary
def with_optics(subspace, show_cluster=False):
    dist_dic = subspace.dist_dic
    dist_matrix = np.array(list(dist_dic.values()))
    ids = list(dist_dic.keys())
    min_pts = int(round(np.log(len(ids))))
    cluster = OPTICS(min_samples=min_pts, metric='precomputed').fit(dist_matrix)
    if show_cluster:
        show_clustr_plot_opt(cluster, dist_matrix)
    id_cluster = dict((b, a) for (a, b) in zip(cluster.labels_, ids))
    return id_cluster