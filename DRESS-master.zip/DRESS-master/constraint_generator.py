from pathlib import Path
from data_model import DataModel
import numpy
import pandas as pd
from dplython import (DplyFrame, X, select, sift, dplython, pandas)

#generate_constraint gibt einen Dataframe des entsprechenden Constraints zurück
#amount für die Menge an jeweiligen constraints
#constraint_type für True ML-Constraint, sonst NL-Constraint
#Seed für den random Seed
#Dataframe muss im dplython Format sein


def correct_constraint(dataset):
    s1 = set()
    for a in dataset:
        s1.add(frozenset(a))
    data1 = list()
    for s in s1:
        data1.append(list(s))

    if len(data1) == len(dataset):
        return True
    else:
        return False


def generate_constraints(dataframe, constraint_type, amount, seed, class_name="Class", create_file=True):
    if "id" not in dataframe.columns:
        dataframe = DataModel.create_data_with_ids(dataframe)
    dataframe = dataframe >> select(X.id, X[class_name])
    constraint_frame = pd.DataFrame(columns=['id_1', 'id_2'])
    seed_value = 100
    while True:
        first_object_frame = dataframe.sample(n=amount, replace=True, random_state=seed)
        first_object_frame = first_object_frame.reset_index(drop=True)
        testset = []
        for i in range(amount):
            y = False
            if constraint_type == "ML":
                y = dataframe >> sift(X[class_name] == first_object_frame.iat[i, 1], X.id != first_object_frame.iat[i, 0]) >> select(X.id)
            elif constraint_type == "NL":
                y = dataframe >> sift(X[class_name] != first_object_frame.iat[i, 1], X.id != first_object_frame.iat[i, 0]) >> select(X.id)
            y = y.sample(n=1, random_state=seed)
            x = y.iat[0, 0]
            constraint_frame.loc[i] = first_object_frame.loc[i, 'id'], x
            testset.append([first_object_frame.loc[i, 'id'], x])
            seed_value = seed_value + 100
            seed = numpy.random.seed(seed_value)
        if correct_constraint(testset):
            break
    if create_file:
        if constraint_type == "ML":
            constraint_frame.to_csv(r'ML_constraints.csv', index=False)
        elif constraint_type == "NL":
            constraint_frame.to_csv(r'NL_constraints.csv', index=False)
    return constraint_frame

#test constaints
if __name__ == "__main__":
    data_path = Path(r"C:\Users\\Desktop\SHIP_Daten\SHIPdatStudents.csv")
    data_frame = dplython.DplyFrame(pandas.read_csv(data_path))
    generate_constraints(data_frame,"NL",2,8)
    #df = pd.read_csv(r'SHIPS_data.csv')
    #main_frame = DplyFrame(df)
    #seed = numpy.random.seed(1234)
    #generate_constraints(8, True, seed, main_frame)