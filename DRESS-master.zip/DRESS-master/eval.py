from sklearn.model_selection import KFold
from sklearn.neighbors import KNeighborsClassifier
import DRESS
import config
import heom
import numpy as np
import data_model
from sklearn.naive_bayes import GaussianNB
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder
import os
import warnings
warnings.filterwarnings('ignore')


class DRESS_Eval:
    def __init__(self, data_path, features_path, cons_amount=config.Constraints_amount, feamle=None, limit=False, seed=256):
        self.data = data_model.DataModel(data_path, feature_path=features_path, female=feamle, limit=limit)
        self.female = feamle
        self.limit = limit
        self.cons_amount = cons_amount

    def preprocess(self, X, features):
        imputer = SimpleImputer(missing_values=np.nan, strategy='most_frequent')
        imputer_mean = SimpleImputer(missing_values=np.nan, strategy='mean')
        X = X.copy()
        for f in features:
            if X[f.name].notna().any():
                if f.kind in ['interval', 'continuous']:
                    X[f.name] = imputer_mean.fit_transform(X.loc[:, [f.name]])
                else:
                    X[f.name] = imputer.fit_transform(X.loc[:, [f.name]])
                    le = LabelEncoder()
                    X[f.name] = le.fit_transform(X.loc[:, [f.name]])
            else:
                X[f.name] = 0
        return X

    def knn(self, use_dress, save_to, clustring_algorithmus="DBSCAN"):
        if use_dress:
            algorthim_dir = '/DRESS/dbscan' if clustring_algorithmus == "DBSCAN" else "/DRESS/optics"
            save_to += algorthim_dir
        else:
            save_to += '/All'
        scores = []
        cv = KFold(n_splits=10, random_state=42, shuffle=False)
        X = self.data.data_frame
        lables = self.data.data_frame["Class"].to_numpy()
        y = lables
        i = 1
        for train_index, test_index in cv.split(X):
            print("Train Index: ", train_index, "\n")
            print("Test Index: ", test_index)
            X_train, X_test, y_train, y_test = X.iloc[train_index, :], X.iloc[test_index, :], y[train_index], y[test_index]
            features_types = [f.kind for f in self.data.features]
            if use_dress:
                constraints = data_model.Constraints(False, X_train, self.cons_amount, 15)
                dr = DRESS.DRESS(data=self.data, constraints=constraints, clustering_method=clustring_algorithmus, feamle=self.female, limt=self.limit, seed=False)
                sbest = dr.start()
                features = sbest.get_features()
                feature_names = [f.name for f in features]
                features_types = [f.kind for f in features]
                X_train = X_train[feature_names].to_numpy()
                X_test = X_test[feature_names].to_numpy()
                np.savetxt(save_to + "/subspace" + str(i) + '.csv', np.array([feature_names]), fmt='%s', delimiter=",")
            else:
                X_train = X_train.drop(columns=['id', 'Class']).to_numpy()
                X_test = X_test.drop(columns=['id', 'Class']).to_numpy()
            X_train1 = heom.heom_array(X_train, features_types)
            X_test1 = heom.heom_array_ids(X_test, X_train, features_types)
            knn = KNeighborsClassifier(n_neighbors=5, algorithm="brute", metric='precomputed')
            knn.fit(X_train1, y_train)
            y_pred = knn.predict(X_test1)
            scores.append(knn.score(X_test1, y_test))
            np.savetxt(save_to + "/res" + str(i) + '.csv', np.array([y_pred, y_test]), fmt='%s', delimiter=",")
            i += 1
        self.dress_score = np.mean(scores)

    def naive_bayes(self, use_dress,save_to, clustring_algorithmus="DBSCAN"):
        X = self.data.data_frame
        y = self.data.data_frame["Class"].to_numpy()
        if use_dress:
            algorthim_dir = '/DRESS/dbscan' if clustring_algorithmus == "DBSCAN" else "/DRESS/optics"
            save_to += algorthim_dir
        else:
            save_to += '/All'
        cv = KFold(n_splits=10, random_state=42, shuffle=False)
        i = 1
        for train_index, test_index in cv.split(X):
            print("Train Index: ", train_index, "\n")
            print("Test Index: ", test_index)
            X_train, X_test, y_train, y_test = X.iloc[train_index, :], X.iloc[test_index, :], y[train_index], y[test_index]
            features = self.data.features
            if use_dress:
                constraints = data_model.Constraints(False, X_train, self.cons_amount, 15)
                dr = DRESS.DRESS(data=self.data, constraints=constraints, clustering_method=clustring_algorithmus, feamle=self.female,
                                 limt=self.limt, seed=False)
                sbest = dr.start()
                features = sbest.get_features()
                feature_names = [f.name for f in features]
                X_train = X_train[feature_names]
                X_test = X_test[feature_names]
                np.savetxt(save_to + "/subspace" + str(i) + '.csv', np.array([feature_names]), fmt='%s', delimiter=",")
            else:
                X_train = X_train.drop(columns=['id', 'Class'])
                X_test = X_test.drop(columns=['id', 'Class'])
            X_train = self.preprocess(X_train, features)
            X_test = self.preprocess(X_test, features)
            le = LabelEncoder()
            y_train = le.fit_transform(y_train)
            gnb = GaussianNB()
            # Train the model using training sets
            gnb.fit(X_train, y_train)
            # Predict the response for test dataset
            y_pred = gnb.predict(X_test)
            y_pred = le.inverse_transform(y_pred)
            np.savetxt(save_to + "/res" + str(i) + '.csv', np.array([y_pred, y_test]), fmt='%s', delimiter=",")
            i += 1

if __name__ == "__main__":
    data_path = config.DATA_PATH
    feature_path = config.FEATURE_PATH
    evalution = DRESS_Eval(data_path, features_path=feature_path, feamle=config.FEMALE, limit=False, seed=357)
    print("Evaluate DRESS with ")
    print("(1) Naive Bayes: ")
    print("(2) KNN: ")
    val = input("Select method for Evaluation: ")
    while int(val) not in [1, 2]:
        val = input("Select method for Evaluation: ")
    print(" Use DRESS with: ")
    print("(1) DBSCAN ")
    print("(2) OPTICS ")
    alg = input("Select method for Evaluation: ")
    while int(alg) not in [1, 2]:
        alg = input("Select method for Evaluation: ")
    alg = "DBSCAN" if int(alg) == 1 else "OPTICS"
    if int(val) == 1:
        if not os.path.exists("Result/naive_bayes/All"):
            os.makedirs("Result/naive_bayes/All")
            os.mkdir("Result/naive_bayes/DRESS")
            os.mkdir("Result/naive_bayes/DRESS/dbscan")
            os.mkdir("Result/naive_bayes/DRESS/optics")
        evalution.naive_bayes(use_dress=True, save_to='Result/naive_bayes', clustring_algorithmus=alg)
        evalution.naive_bayes(use_dress=False, save_to='Result/naive_bayes')
    else:
        if not os.path.exists("Result/knn/All"):
            os.makedirs("Result/knn/All")
            os.mkdir("Result/knn/DRESS")
            os.mkdir("Result/knn/DRESS/dbscan")
            os.mkdir("Result/knn/DRESS/optics")
        evalution.knn(use_dress=True, save_to='Result/knn', clustring_algorithmus=alg)
        evalution.knn(use_dress=False, save_to='Result/knn')
